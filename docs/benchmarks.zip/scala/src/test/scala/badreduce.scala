object BadReduce {

import NumpyMatchTypes._

// start section badreducescala
val img_batch = random_normal(#:(25, #:(256, #:(256, #:(3, Ø)))))
val avg_colors = mean(img_batch, #:(0, #:(1, #:(2, Ø))))
val avg_color_square = reshape(avg_colors, #:(5, #:(5, Ø)))
// end section badreducescala

}
